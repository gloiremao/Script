
public class Video {
	public int id;
	public String filename;
	public String width;
	public String height;
	public String frame;
	public String biterate;
	
	public void setResolution(String w,String h){
		this.width = w;
		this.height = h;
	}
	
}